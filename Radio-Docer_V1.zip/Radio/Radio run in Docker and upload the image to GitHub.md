# Radio: run in Docker and upload the image to GitHub

Use this on the Pi where you build the image. At the end the image sits on GitHub (ghcr.io) and any other Pi can download it. The second document covers installing it on a fresh machine.

## 1. Put the three files in one folder

```bash
mkdir -p ~/radio-pi/data && cd ~/radio-pi
```

Copy these three files into `~/radio-pi`: `radio.py` (the latest one from chat), `Dockerfile` and `docker-compose.yml`. Their contents are below in case you need to retype them.

**Dockerfile**

```dockerfile
FROM python:3.11-slim-bookworm

LABEL org.opencontainers.image.source="https://github.com/roushan-kmr/radio-pi"

RUN apt-get -o Acquire::ForceIPv4=true update \
 && apt-get -o Acquire::ForceIPv4=true install -y --no-install-recommends \
        mpv alsa-utils ca-certificates \
 && rm -rf /var/lib/apt/lists/*

WORKDIR /app
COPY radio.py /app/radio.py

ENV HOME=/data \
    RADIO_DIR=/data \
    PYTHONUNBUFFERED=1

EXPOSE 8000
CMD ["python3", "/app/radio.py"]
```

**docker-compose.yml**

```yaml
services:
  radio:
    image: ghcr.io/roushan-kmr/radio-pi:v1
    container_name: radio
    init: true
    user: "1000:1000"          # must match `id -u` of the Pi user
    ports:
      - "8000:8000"
    devices:
      - /dev/snd:/dev/snd      # direct ALSA access (HDMI, USB DAC, HAT)
    group_add:
      - audio                  # permission to use /dev/snd
    volumes:
      - ./data:/data           # favourites, AutoPlay, AudioOutput, custom channels
    restart: unless-stopped
```

If `id -u` does not print 1000, change the `user:` line to match.

## 2. Stop the old radio container

Both would use port 8000:

```bash
cd ~/Radio && docker compose down
cd ~/radio-pi
```

Optional: keep your settings by copying them into the new data folder (skip any file you do not have):

```bash
cp ~/Radio/{favorites.json,AutoPlay.txt,AudioOutput.txt,NonAIRchannels.txt} ~/radio-pi/data/
```

## 3. Build the image

```bash
cd ~/radio-pi
docker build -t ghcr.io/roushan-kmr/radio-pi:v1 .
```

This installs mpv and alsa-utils. If the apt step is very slow on your network, build on a PC instead:

```bash
docker buildx build --platform linux/arm64 -t ghcr.io/roushan-kmr/radio-pi:v1 --push .
```

(do step 5 first, so you are logged in to GitHub).

## 4. Run it and test

```bash
docker compose up -d
docker compose logs --tail 20
docker exec radio aplay -l
```

The logs should show a line like `N channels, N favourites ...`, and `aplay -l` should list your sound cards. Open `http://<PI_IP>:8000`, choose your DAC in the dropdown and play a channel. Wait up to 20 seconds on the first start, because the station list is downloaded first.

## 5. Create a GitHub token (one time)

On github.com open Settings, Developer settings, Personal access tokens, Tokens (classic), Generate new token (classic). Tick `write:packages` and `read:packages`, generate, and copy the token. GitHub shows it only once.

## 6. Upload the image

```bash
export CR_PAT=<your-token>
echo $CR_PAT | docker login ghcr.io -u roushan-kmr --password-stdin
docker push ghcr.io/roushan-kmr/radio-pi:v1
```

You should see `Login Succeeded`, and then the layers upload.

## 7. Make the image public

New images are private. On github.com open your profile, Packages, radio-pi, Package settings, Change visibility, Public. Then other Pis can download it without logging in.

## 8. Releasing a new version later

Change `radio.py`, then build and push with a new tag:

```bash
docker build -t ghcr.io/roushan-kmr/radio-pi:v2 .
docker push ghcr.io/roushan-kmr/radio-pi:v2
```

On this Pi, change `v1` to `v2` in `docker-compose.yml` and run `docker compose up -d`. Your data folder is not touched.
