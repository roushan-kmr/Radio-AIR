# Radio: download the image and install it on a fresh Pi

Use this on a new Raspberry Pi (or any Linux machine with a sound card). It downloads the radio image from GitHub and starts it. You do not need radio.py or the Dockerfile on this machine, only a compose file.

Before you start, the image must already be uploaded and set to Public (see the first document).

## 1. Check the machine

Run this on the new Pi:

```bash
uname -m
aplay -l
```

`uname -m` should print `aarch64` (64-bit Raspberry Pi OS), which matches the image. If it prints `armv7l` (32-bit OS), install the 64-bit OS, or ask for a 32-bit build of the image.

`aplay -l` should list your sound cards (HDMI ports, and your DAC if you have one). If a DAC HAT is missing from the list, copy its `dtoverlay=...` line from `/boot/firmware/config.txt` on your first Pi into the same file on this one, then run `sudo reboot`.

## 2. Install Docker

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
sudo systemctl enable docker
```

Log out and log back in so the group change takes effect. Check it with `docker ps`.

## 3. Create the folder and compose file

```bash
id -u
mkdir -p ~/Radio/data && cd ~/Radio
nano docker-compose.yml
```

Paste this into the file, then save with Ctrl+O, Enter, Ctrl+X:

```yaml
services:
  radio:
    image: ghcr.io/roushan-kmr/radio-pi:v1
    container_name: radio
    init: true
    user: "1000:1000"          # must match the number printed by `id -u`
    ports:
      - "8000:8000"
    devices:
      - /dev/snd:/dev/snd
    group_add:
      - audio
    volumes:
      - ./data:/data
    restart: unless-stopped
```

If `id -u` printed a number other than 1000, put that number in the `user:` line in both places (for example `"1001:1001"`).

Optional: to bring over your favourites and custom channels, copy `favorites.json` and `NonAIRchannels.txt` from the old Pi into `~/Radio/data` now.

## 4. Download and start

```bash
docker compose pull
docker compose up -d
```

If the pull says `unauthorized` or `denied`, the image is still private. Either make it Public on GitHub, or log in first with a token that has `read:packages`:

```bash
echo <token> | docker login ghcr.io -u roushan-kmr --password-stdin
```

## 5. Check that it works

```bash
docker compose logs --tail 20
docker exec radio aplay -l
```

The logs should show a line like `N channels, N favourites ...`, and `aplay -l` inside the container should list the same cards as on the machine. Now open `http://<NEW_PI_IP>:8000` on your phone (find the address with `hostname -I`). Wait up to 20 seconds on the first start, then choose your output device in the dropdown and play a channel.

Turn on Auto Play in the page if you want the last channel to resume after a reboot. The container starts by itself at every boot.

## 6. Updating to a new version

When a new version (for example `v2`) is uploaded, change `v1` to `v2` in `docker-compose.yml`, then:

```bash
docker compose pull
docker compose up -d
docker image prune
```

Your data folder is not touched.

## 7. If something goes wrong

- **`exec format error`:** wrong CPU type. Check `uname -m` (step 1).
- **Dropdown shows only "Default ALSA Output":** the container cannot see the sound cards. Check that `aplay -l` works on the machine itself, and that the compose file has the `devices` and `group_add` lines.
- **Playing but no sound:** choose your DAC in the dropdown, because the default output is usually HDMI.
- **Page does not open:** wait 20 seconds, then run `docker compose logs`.
- **Permission denied in /data:** the `user:` number does not match `id -u`.

## Alternative: no GitHub

To copy the image straight from the first Pi instead:

```bash
# on the first Pi
docker save ghcr.io/roushan-kmr/radio-pi:v1 | gzip > radio-pi-v1.tar.gz
scp radio-pi-v1.tar.gz pi@<NEW_PI_IP>:~

# on the new Pi
gunzip -c ~/radio-pi-v1.tar.gz | docker load
```

Then continue from step 3 and skip `docker compose pull`.
