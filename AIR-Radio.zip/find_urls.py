#!/usr/bin/env python3
"""Find the current stream URLs for chosen Akashvani channels.

Downloads the live radio page, pulls the station list out of it, prints the
URL for each channel you care about, checks that the stream really responds,
and tells you if a URL has changed since the last run.

Run:  python3 find_urls.py
Add or remove channels in the CHANNELS list below.
"""
import html
import json
import re
import sys
import urllib.request
from pathlib import Path

CHANNELS = [
    "Live News 24x7",
    "Vividh Bharati",
    "FM Gold Delhi",
    "FM Rainbow Delhi",
]

SOURCE_URL = "https://akashvani.gov.in/radio/live.php"
SAVE_FILE = Path(__file__).resolve().parent / "radio_urls.json"
PATTERN = re.compile(
    r"name:\s*'([^']*)',\s*image:\s*'[^']*',\s*live_url:\s*'([^']*)'"
)
HEADERS = {"User-Agent": "Mozilla/5.0"}


def fetch(url, nbytes=None, timeout=20):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(nbytes) if nbytes else r.read()
        return r.status, data


def get_stations():
    _, raw = fetch(SOURCE_URL)
    text = raw.decode("utf-8", errors="ignore")
    stations = {}
    for name, url in PATTERN.findall(text):
        name = html.unescape(name).strip()
        if name and url and name not in stations:
            stations[name] = url
    return stations


def find_channel(stations, wanted):
    """Exact name (case-insensitive) first, then names that contain it."""
    for name, url in stations.items():
        if name.lower() == wanted.lower():
            return name, url, []
    partial = [(n, u) for n, u in stations.items() if wanted.lower() in n.lower()]
    if partial:
        return partial[0][0], partial[0][1], [n for n, _ in partial[1:]]
    return None, None, []


def check_stream(url):
    """True if the URL answers with an HLS playlist."""
    try:
        status, data = fetch(url, nbytes=2048, timeout=10)
        return status == 200 and data.lstrip().startswith(b"#EXTM3U")
    except Exception:
        return False


def main():
    try:
        stations = get_stations()
    except Exception as e:
        print(f"Could not download the page: {e}")
        return 2

    if not stations:
        print("Page downloaded, but no stations were found.")
        print("The page layout has probably changed, so the pattern in this")
        print("script needs updating.")
        return 2

    print(f"Stations found on the page: {len(stations)}\n")

    old = {}
    if SAVE_FILE.exists():
        try:
            old = json.loads(SAVE_FILE.read_text())
        except Exception:
            old = {}

    new = {}
    problems = 0
    for wanted in CHANNELS:
        name, url, others = find_channel(stations, wanted)
        print(f"== {wanted}")
        if not url:
            print("   NOT FOUND on the page (renamed or removed?)\n")
            problems += 1
            continue
        new[wanted] = url
        if name != wanted:
            print(f"   matched as: {name}")
        if others:
            print(f"   other matches ignored: {', '.join(others)}")
        print(f"   {url}")

        if wanted not in old:
            note = "NEW (first time seen)"
        elif old[wanted] != url:
            note = f"CHANGED (was {old[wanted]})"
            problems += 1
        else:
            note = "same as last run"
        alive = "playlist OK" if check_stream(url) else "NOT RESPONDING"
        if alive == "NOT RESPONDING":
            problems += 1
        print(f"   {note}; {alive}\n")

    merged = {**old, **new}
    SAVE_FILE.write_text(json.dumps(merged, indent=2))
    print(f"Saved to {SAVE_FILE}")
    if problems:
        print(f"{problems} item(s) need attention (see above).")
        return 1
    print("All good.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
